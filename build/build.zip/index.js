/**
 * Start Yisi Backed
 */
import "./lib/index.js";