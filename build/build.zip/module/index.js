import getSystemInfo from "./info.js";
import getSystemState from "./state.js";

export {
    getSystemInfo,
    getSystemState,
}